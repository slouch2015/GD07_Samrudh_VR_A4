using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
/// <summary>
    /// Add this component to a GameObject and call the <see cref="IncrementText"/> method
    /// in response to a Unity Event to update a text display to count up with each event.
    /// </summary>
    public class IncrementUIText : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("The Text component this behavior uses to display the incremented value.")]
        Text m_Text1;
        [SerializeField]
        [Tooltip("The Text component this behavior uses to display the incremented value.")]
        Text m_Text2;
        [SerializeField]
        [Tooltip("The Text component this behavior uses to display the incremented value.")]
        Text m_Text3;

        /// <summary>
        /// The Text component this behavior uses to display the incremented value.
        /// </summary>
        public Text text1
        {
            get => m_Text1;
            set => m_Text1 = value;
        }
        public Text text2
        {
            get => m_Text2;
            set => m_Text2 = value;
        }
        public Text text3
        {
            get => m_Text3;
            set => m_Text3 = value;
        }

        int m_Count1;
        int m_Count2;
        int m_Count3;
        public GameObject Door;

        /// <summary>
        /// Increment the string message of the Text component.
        /// </summary>
        public void IncrementText1()
        {
            m_Count1 = (m_Count1 + 1) % 10; // Reset to 0 when it reaches 10
            if (m_Text1 != null)
                m_Text1.text = m_Count1.ToString();
        }
        public void IncrementText2()
        {
            m_Count2 = (m_Count2 + 1) % 10; // Reset to 0 when it reaches 10
            if (m_Text2 != null)
                m_Text2.text = m_Count2.ToString();
        }
        public void IncrementText3()
        {
            m_Count3 = (m_Count3 + 1) % 10; // Reset to 0 when it reaches 10
            if (m_Text3 != null)
                m_Text3.text = m_Count3.ToString();
        }

        public void CheckCode()
        {
            if (m_Text1 != null && m_Text2 != null && m_Text3 != null)
            {
                // Concatenate the text values of m_Text1, m_Text2, and m_Text3
                string combinedText = m_Text1.text + m_Text2.text + m_Text3.text;

                // Check if the combined text forms the number "451"
                if (combinedText == "451")
                {
                    // Execute the OpenDoor method
                    OpenDoor();
                }
            }
        }

        void OpenDoor()
        {
            Door.SetActive(false);
        }

        public void RestartGame()
        {
            SceneManager.LoadScene("EscapeRoom");
        }
    }
